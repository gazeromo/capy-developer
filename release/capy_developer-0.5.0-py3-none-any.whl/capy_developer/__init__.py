"""Capy Developer V0."""

__version__ = "0.5.0"
