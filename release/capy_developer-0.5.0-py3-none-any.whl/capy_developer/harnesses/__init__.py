"""Replaceable interactive harness adapters."""
