"""Capy Developer V0."""

__version__ = "0.7.0"
