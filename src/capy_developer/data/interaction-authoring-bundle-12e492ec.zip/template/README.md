# Hello capability

This generated capability demonstrates the smallest read-only script contract.

`capability.toml` defines executable truth. `interaction.json` defines the
provisional human meaning for one operation. Keep every human field, result
fact, artifact, and effect consistent with the descriptor, then run
`interaction-check` before completion.

Write request and result schemas directly under `input_schema` and
`result_schema` in `capability.toml`. Declare every resource slot and semantic
connection operation before using it. Normal success calls `ctx.complete(...)`;
causal application failure calls `ctx.fail(...)`. Artifacts are optional and
must agree with `side_effect`. An uncaught exception is a software defect.
