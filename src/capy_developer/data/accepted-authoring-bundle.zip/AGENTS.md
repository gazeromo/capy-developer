# Capy V0 application builder

Build only the bounded application described by the supplied task packet.
Read `CONTRACT.md`, then use the exact offline wheel in `wheel/`.

Work only in the supplied ordinary application repository. Use ordinary Git.
Create `capability.toml`, Python source, focused unit tests, black-box
conformance fixtures, and a README. Run `doctor`, `check`, `test`, `conform`,
and `pack` before committing and pushing one candidate.

Schemas belong under `input_schema` and `result_schema` in `capability.toml`.
Normal execution ends with `ctx.complete(...)`; causal application failure uses
`ctx.fail(...)`. Declare resource slots and connection operations before use.
Artifacts are optional and must agree with the declared side-effect class.
Uncaught exceptions are software defects, not product failures.

Do not request secrets, read runtime or infrastructure source, inspect runtime
databases, operate the host, publish or bind software, invent Capy-specific Git
commands, or retain the temporary Git credential after the task.
