#!/usr/bin/env python3
"""Return one deterministic greeting."""

from capy_script import ConnectionError, Context, ScriptFailure


def main() -> None:
    ctx = Context()
    if ctx.request != {}:
        ctx.fail("REQUEST_INVALID")
    ctx.complete({"message": "hello"})


if __name__ == "__main__":
    try:
        main()
    except (ConnectionError, ScriptFailure) as error:
        print(error, file=__import__("sys").stderr)
        raise SystemExit(2) from None

