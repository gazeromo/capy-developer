# Hello capability

This generated capability demonstrates the smallest read-only script contract.

Write request and result schemas directly under `input_schema` and
`result_schema` in `capability.toml`. Declare every resource slot and semantic
connection operation before using it. Normal success calls `ctx.complete(...)`;
causal application failure calls `ctx.fail(...)`. Artifacts are optional and
must agree with `side_effect`. An uncaught exception is a software defect.
