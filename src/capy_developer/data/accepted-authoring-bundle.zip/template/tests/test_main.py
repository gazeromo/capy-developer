import unittest


class HelloTests(unittest.TestCase):
    def test_expected_greeting(self):
        self.assertEqual("hello", "hello")

